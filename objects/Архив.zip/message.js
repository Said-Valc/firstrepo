

let obj = 
{
	id: 1,
	author: 'said',
	text: 'Привет',
	type: 'Входящее',
	time: '12:39'
}

let info = [
	{
		id: 1,
		author: 'said',
		text: 'Привет',
		type: 'Входящее',
		time: '12:39'
	},
	{
		id: 2,
		author: 'maga',
		text: 'Привет',
		type: 'Входящее',
		time: '13:39'
	},
	{
		id: 3,
		author: 'dav',
		text: 'Привет',
		type: 'Входящее',
		time: '14:39'
	},
	{
		id: 4,
		author: 'ol',
		text: 'Привет',
		type: 'Входящее',
		time: '16:39'
	},
	{
		id: 5,
		author: 'asd',
		text: 'Привет',
		type: 'Входящее',
		time: '18:39'
	},

]