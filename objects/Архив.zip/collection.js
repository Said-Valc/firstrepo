

let student1 = {
	name: 'muhammad',
	lastname: 'mahmudov',
	address: 'grozny',
}

let student2 = {
	name: 'umar',
	lastname: 'umarov',
	address: 'grozny',
}

let student3 = {
	name: 'abrek',
	lastname: 'abrekov',
	address: 'grozny',
}


let arr = [
	{
     name: 'umar',
	 lastname: 'umarov',
	 address: 'grozny',
	},
	{
     name: 'abrek',
	 lastname: 'abrekov',
	 address: 'grozny',
	}
]